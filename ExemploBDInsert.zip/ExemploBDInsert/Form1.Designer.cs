﻿namespace ExemploBDInsert
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btn_ConfirmarCadastro = new Button();
            btn_MostrarDados = new Button();
            button1 = new Button();
            lbl_Nome = new Label();
            lbl_Email = new Label();
            txt_Nome = new TextBox();
            txt_Email = new TextBox();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            button2 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(170, 78);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(503, 150);
            dataGridView1.TabIndex = 0;
            // 
            // btn_ConfirmarCadastro
            // 
            btn_ConfirmarCadastro.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            btn_ConfirmarCadastro.Location = new Point(170, 469);
            btn_ConfirmarCadastro.Name = "btn_ConfirmarCadastro";
            btn_ConfirmarCadastro.Size = new Size(503, 56);
            btn_ConfirmarCadastro.TabIndex = 1;
            btn_ConfirmarCadastro.Text = "Confirmar Cadastro";
            btn_ConfirmarCadastro.UseVisualStyleBackColor = true;
            btn_ConfirmarCadastro.Visible = false;
            btn_ConfirmarCadastro.Click += btn_Cadastrar_Click;
            // 
            // btn_MostrarDados
            // 
            btn_MostrarDados.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            btn_MostrarDados.Location = new Point(425, 247);
            btn_MostrarDados.Name = "btn_MostrarDados";
            btn_MostrarDados.Size = new Size(248, 56);
            btn_MostrarDados.TabIndex = 2;
            btn_MostrarDados.Text = "Mostrar Dados";
            btn_MostrarDados.UseVisualStyleBackColor = true;
            btn_MostrarDados.Click += btn_MostrarDados_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            button1.Location = new Point(170, 247);
            button1.Name = "button1";
            button1.Size = new Size(241, 56);
            button1.TabIndex = 3;
            button1.Text = "Cadastrar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // lbl_Nome
            // 
            lbl_Nome.AutoSize = true;
            lbl_Nome.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            lbl_Nome.Location = new Point(170, 319);
            lbl_Nome.Name = "lbl_Nome";
            lbl_Nome.Size = new Size(131, 20);
            lbl_Nome.TabIndex = 4;
            lbl_Nome.Text = "Informe o nome: ";
            lbl_Nome.Visible = false;
            lbl_Nome.Click += lbl_Nome_Click;
            // 
            // lbl_Email
            // 
            lbl_Email.AutoSize = true;
            lbl_Email.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            lbl_Email.Location = new Point(170, 358);
            lbl_Email.Name = "lbl_Email";
            lbl_Email.Size = new Size(131, 20);
            lbl_Email.TabIndex = 5;
            lbl_Email.Text = "Informe o e-mail:";
            lbl_Email.Visible = false;
            lbl_Email.Click += lbl_Email_Click;
            // 
            // txt_Nome
            // 
            txt_Nome.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            txt_Nome.Location = new Point(324, 319);
            txt_Nome.Name = "txt_Nome";
            txt_Nome.Size = new Size(349, 27);
            txt_Nome.TabIndex = 6;
            txt_Nome.Visible = false;
            txt_Nome.TextChanged += txt_Nome_TextChanged;
            // 
            // txt_Email
            // 
            txt_Email.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            txt_Email.Location = new Point(324, 358);
            txt_Email.Name = "txt_Email";
            txt_Email.Size = new Size(349, 27);
            txt_Email.TabIndex = 7;
            txt_Email.Visible = false;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(324, 391);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(349, 23);
            textBox1.TabIndex = 8;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(363, 420);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(349, 23);
            textBox2.TabIndex = 9;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            label1.Location = new Point(170, 394);
            label1.Name = "label1";
            label1.Size = new Size(149, 20);
            label1.TabIndex = 10;
            label1.Text = "Informe o telefone: ";
            label1.Visible = false;
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            label2.Location = new Point(170, 423);
            label2.Name = "label2";
            label2.Size = new Size(187, 20);
            label2.TabIndex = 11;
            label2.Text = "Informe o nacionalidade: ";
            label2.Visible = false;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold);
            button2.Location = new Point(765, 538);
            button2.Name = "button2";
            button2.Size = new Size(130, 33);
            button2.TabIndex = 12;
            button2.Text = "ir para o lobby";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(923, 592);
            Controls.Add(button2);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(txt_Email);
            Controls.Add(txt_Nome);
            Controls.Add(lbl_Email);
            Controls.Add(lbl_Nome);
            Controls.Add(button1);
            Controls.Add(btn_MostrarDados);
            Controls.Add(btn_ConfirmarCadastro);
            Controls.Add(dataGridView1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button btn_ConfirmarCadastro;
        private Button btn_MostrarDados;
        private Button button1;
        private Label lbl_Nome;
        private Label lbl_Email;
        private TextBox txt_Nome;
        private TextBox txt_Email;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label1;
        private Label label2;
        private Button button2;
    }
}
