﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExemploBDInsert
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            update update = new update();
            this.Hide();
            update.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            delete update = new delete();
            this.Hide();
            update.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            this.Hide();
            form.ShowDialog();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            update update = new update();
            this.Hide();
            update.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form8 form = new Form8();
            this.Hide();
            form.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form10 form = new Form10();
            this.Hide();
            form.ShowDialog();
        }
    }
}
